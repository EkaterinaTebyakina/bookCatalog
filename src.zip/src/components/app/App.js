import './App.css';
import { useState, useEffect } from 'react';
import BooksList from '../booksList/booksList';
import AddBook from '../addBook/addBook';
import useFirestore from '../../services/useFirestore';

function App() {

  const [books, setBooks] = useState([]);
  const {loading, error, getBooks, deleteBook} = useFirestore();

  useEffect(() => {
    onRequest();
  }, [])

  const onRequest = async () => {
      await getBooks()
          .then(newBooks => {setBooks(newBooks)});      
  }

  const onBookAdded = () => {
    onRequest();
  }

  const onBookDeleted = (id) => {
    deleteBook(id);
    setBooks([...books.slice(0, id), ...books.slice(id + 1)])
  }

  return (
      <div className="app">
        <div className="addBook">
          <AddBook onBookAdded={onBookAdded}/>
        </div>    
        <div className="bookList">
          <BooksList books={books} onBookDeleted={onBookDeleted}/>
        </div>  
      </div>
  );
}

export default App;