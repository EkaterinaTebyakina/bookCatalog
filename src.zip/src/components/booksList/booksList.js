import './booksList.css';
import useFirestore from '../../services/useFirestore';
import {useState, useEffect} from 'react'
import ErrorMessage from '../errorMessage/ErrorMessage';
import Spinner from '../spinner/Spinner';

const BooksList = (props) => {

    let books = props.books;
    // const [books, setBooks] = useState([]);
    const {loading, error} = useFirestore();

    useEffect(() => {
        //elements = renderList(groupBooksByYear(), false);
    }, [props.books])

    // useEffect(() => {
    //     onRequest();
    // }, [props.isBookAdded]);

    // const onRequest = async () => {
    //     await getBooks()
    //         .then(newBooks => {setBooks(newBooks)});
        
    // }

    const setToMap = (map, book, key) => {

        if (map.has(key)) {

            map.set(key, [...map.get(key), book]);

        } else {

            map.set(key, [book]);
        }
    }

    const groupBooksByYear = () => {

        if (books) {

            let map = new Map();

            books
            .sort((current, next) => {
                if (current.publicationYear && next.publicationYear) {
                    return next.publicationYear - current.publicationYear;
                } else if (!current.publicationYear) {
                    return 1;
                } else {
                    return -1;
                }
            })
            .forEach(book => {

                if (book.publicationYear) {

                    setToMap(map, book, book.publicationYear);

                } else {

                    setToMap(map, book, "Год публикации неизвестен");

                }
            })

            //отсортировать книги по названию

            for (let year of map.keys()) {

                map.set(year, map.get(year).sort((cur, next) => cur.title > next.title ? 1 : -1))
            }

            return map;
        }
        
    }

    const findGoodBook = () => {

        if (books) {

            //фильтруем по году
            let filteredByYear = books.filter(book => new Date().getFullYear() - book.publicationYear >= 3);

            if (filteredByYear.length > 0) {
                //группируем по рейтингу
                let map = new Map();
                filteredByYear.forEach(book => {

                    if (book.rating) {
                        setToMap(map, book, book.rating);
                    } else {
                        setToMap(map, book, 0);
                    }
                })

                //отбираем книги подходящие по году и с макс рейтингом
                let maxRating = 0;
                maxRating = Math.max(...map.keys());
                let recBooks = map.get(maxRating);

                //если таких книг несколько, выбираем рандомно одну из них
                if (map.get(maxRating).length > 1) {

                    let randomID = Math.floor(Math.random() * (recBooks.length - 1));
                    return [recBooks[randomID]];

                } else {
                    return [recBooks[0]];
                }

            }
        }
    }

    const onDeleteBook = async (id) => {
        //await deleteBook(id);

        let index = books.findIndex(e => e.id === id);
        props.onBookDeleted(id)
        
        //await setBooks([...books.slice(0, index), ...books.slice(index + 1)])
        //await onRequest();
    }

    function renderItem(book,isRec) {

        return (
            <li className="books_item" key={book.id}>
                <div className="book_title"><span>Название: </span>{book.title}</div>
                <ul className="books_grid">
                    <span>Автор/ы: </span>
                    {book.authors.join(', ')}
                </ul>
                {isRec ? <div className="book_year"><span>Год публикации: </span>{book.publicationYear}</div> : null}
                <div className="book_rating"><span>Рейтинг: </span>{book.rating}</div>
                {book.ISBN ? <div className="book_ISBN"><span>ISBN: </span>{book.ISBN}</div> : null}
                <div className='deleteBtn' onClick={(e) => onDeleteBook(book.id)}>удалить</div>
            </li>
        )
    }

    function renderPointOfList(key, books, isRec) {

        const elements = books.map(book => renderItem(book, isRec));

        return (
            <li key={key} className='pointOfList'><span>{key}</span> 
                <ul className="groupBooks">
                    {elements}
                </ul>
            </li>
        )

    }

    function renderList(booksMap, isRec) {
        if (books) {

            let elements = [];

            for (let year of booksMap.keys()) {

                elements.push(renderPointOfList(year, booksMap.get(year)))
            }

            return elements;
        }
    }


    const recBook = findGoodBook() ? renderPointOfList("Рекомендуемая книга", findGoodBook(), true) : null;
    const elements = renderList(groupBooksByYear(), false);

    const errorMessage = error ? <ErrorMessage/> : null;
    const spinner = loading ? <Spinner/> : null;

    return (
        <div className="books__list">
            <ul className="books__grid">
                {recBook}
                {elements}
                {errorMessage}
                {spinner}  
            </ul>
        </div>
    )
}

export default BooksList;